package com.selab.demo.model.enums;

public enum UserType {
    C,A,T,M,TM,S
    // 顾客、管理员、测试部、市场部、测试部主管、授权签字人
}

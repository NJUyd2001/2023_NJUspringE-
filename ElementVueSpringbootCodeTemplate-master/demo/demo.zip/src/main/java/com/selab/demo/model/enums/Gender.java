package com.selab.demo.model.enums;

public enum Gender {
    M, F
}

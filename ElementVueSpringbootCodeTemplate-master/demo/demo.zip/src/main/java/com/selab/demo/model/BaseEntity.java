package com.selab.demo.model;

import javax.persistence.*;

@Entity
@Table
public class BaseEntity {
    /*
    * @Id
    * @GeneratedValue(strategy = GenerationType.IDENTITY)
    * private int id; UID由mysql数据库管理
    */

}


package com.selab.demo.model.enums;

public enum UserType {


    C,T,M,TL,A,Q
    // 客户，测试部，市场部，测试部主管，授权签字人，质量部



}


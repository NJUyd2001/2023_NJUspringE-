package com.selab.demo.model.enums;

public enum SAMPLEDELETE {
    A,B
}

package com.selab.demo.model.enums;

public enum PB_type {
    D,F,G,S,O,E
}
/**
 * 单位性质
 *     D：内资企业
 *     F：外（合）资企业
 *     G：港澳台企业
 *     S：科研院校
 *     O：政府事业团队
 *     E：其他
 */

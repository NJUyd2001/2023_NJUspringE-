package com.selab.demo.dao;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.context.annotation.Bean;


@Mapper
public interface InsertDao {
    void insert(String data); // insert a sqlLine
}

package com.selab.demo.model.enums;

public enum ARCHITECTURE {
    P,U,E;
}

package com.selab.demo.model.enums;

public enum open_to_curr {
    A,B,C,D,E,F,G,H
}

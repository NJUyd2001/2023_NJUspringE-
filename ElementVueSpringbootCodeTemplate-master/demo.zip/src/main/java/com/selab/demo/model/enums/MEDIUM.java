package com.selab.demo.model.enums;

public enum MEDIUM {
    G,U,E
}

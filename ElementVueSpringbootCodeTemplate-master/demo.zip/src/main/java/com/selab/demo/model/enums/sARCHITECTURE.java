package com.selab.demo.model.enums;

public enum sARCHITECTURE {
    C,B,E
}

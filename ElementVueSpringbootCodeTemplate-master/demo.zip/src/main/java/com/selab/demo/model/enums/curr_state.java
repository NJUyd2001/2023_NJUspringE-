package com.selab.demo.model.enums;

public enum curr_state {
    R,W,P,A
}

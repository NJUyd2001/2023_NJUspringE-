package com.selab.demo.model.enums;

public enum Gender{
/*
    F("F"), M("M");

    private String display;



    public String getDisplay() {
        return display;
    }

    public void setDisplay(String display) {
        this.display = display;
    }

    Gender(String display) {
        this.display = display;
    }
    Gender(){}
    */
    F,M
}

package com.selab.demo.model.enums;

public enum testTYPE {
    C,I,A
}
